import { Route, Routes } from 'react-router'
import './App.css'
import { ToastContainer } from 'react-toastify'
import Register from './pages/Register'
import Login from './pages/Login'

function App() {


  return (
    <>
      <Routes>
        <Route path='/register' element={<Register />} />
        <Route path='/*' element={<Login/>}/>
      </Routes>
      <ToastContainer/>
    </>
  )
}

export default App
