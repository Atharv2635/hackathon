import axios from "axios";
import { toast } from "react-toastify";

const base_url = 'http://localhost:4000'

export async function loginUser(email, password) {
    try {
        const userbody = { email, password }
        const url = base_url + '/user/signin'
        const response = await axios.post(url, userbody)
        return response.data
    } catch (ex) {
        toast.error(ex)
    }
}

export async function registerUser(name, email, password, phone_no) {
    try {
        const url = base_url + '/user/signup'
        const body = { name, email, password, phone_no }
        const response = await axios.post(url, body)
        return response.data
    } catch (ex) {
        toast.error(ex)
    }
}

