const config = {
    SALT_ROUND: 10,
    SECRET: 'dbwqonde'
}

module.exports = config