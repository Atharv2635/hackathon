const mysql = require('mysql2')

const pool = mysql.createPool({
    host:'localhost',
    user:'W2_92912_Atharv',
    password:'manager',
    database:'blog_system'
})

module.exports = pool