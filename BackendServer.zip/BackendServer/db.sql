create database blog_system;

use blog_system;

create table users(
    user_id int primary key auto_increment ,
    full_name varchar(20),
    email varchar(50),
    password varchar(50),
    phone_no varchar(10),
    created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP);


create table blogs(
     blog_id int primary key auto_increment ,
    title varchar(20),
    contents varchar(100),
    created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    user_id int,
    foreign key(user_id) references users(user_id),
    category_id int,
    foreign key(category_id) references categories(category_id));

create table categories(
     category_id int primary key auto_increment,
     title varchar(50),
     description varchar(100));